#<<<BloodHunt Enemies>>>
#<<<Importieren wenn nötig>>>



#<<<Klasse>>>
class enemies:
    def __init__(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 1 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Goblin>>>
    def enemy_goblin(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 3 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 2 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Orc>>>
    def enemy_orc(self):
        self.hitpoints = 150 #Current Amount of HP
        self.maxhp = 150 #Maximum Amount of HP
        self.strength = 13 #Damage dealt from enemies
        self.dodgechance = 1 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Stone Golem>>>
    def enemy_stonegolem(self):
        self.hitpoints = 200 #Current Amount of HP
        self.maxhp = 200 #Maximum Amount of HP
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 0 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc
        #<<<Enemy Stone Golem>>>
    def enemy_Ratte(self):
        self.hitpoints = 50 #Current Amount of HP
        self.maxhp = 50 #Maximum Amount of HP
        self.strength = 20 #Damage dealt from enemies
        self.dodgechance = 3 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 3 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc
        #<<<Enemy Stone Golem>>>
    def enemy_Chiefgoblin(self):
        self.hitpoints = 130 #Current Amount of HP
        self.maxhp = 130 #Maximum Amount of HP
        self.strength = 15 #Damage dealt from enemies
        self.dodgechance = 0 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc
        #<<<Enemy Stone Golem>>>
    def enemy_stonegolem(self):
        self.hitpoints = 200 #Current Amount of HP
        self.maxhp = 200 #Maximum Amount of HP
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 0 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

class boss_enemies:
    def __init__(self):
        self.hitpoints = 300 #Current Amount of HP
        self.maxhp = 300 #Maximum Amount of HP
        self.strength = 20 #Damage dealt from enemies
        self.dodgechance = 2 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 2 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc
#<<<Boss Orc Chieftain>>>
    def boss_Brutus(self):
        self.hitpoints = 400 #Current Amount of HP
        self.maxhp = 400 #Maximum Amount of HP
        self.strength = 20 #Damage dealt from enemies
        self.dodgechance = 1 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 2 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc







class tutorial_enemy:
    def training(self):
            self.hitpoints = 50 #Current Amount of HP
            self.maxhp = 50 #Maximum Amount of HP
            self.strength = 10 #Damage dealt from enemies
            self.dodgechance = 0 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
            self.critchance = 0 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy ???>>>
    #def enemy_???(self):
        #self.hitpoints = ++ #Current Amount of HP
        #self.maxhp = ++ #Maximum Amount of HP
        #self.strength = ++ #Damage dealt from enemies
        #self.dodgechance = ++ #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        #self.critchance = ++ #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc