from importlib.metadata.diagnose import inspect
import os
import Classes 
import Items
import random
import pygame
import time
import sys
import EnemiesPage
import inspect
import time

def langsamer_text(text, delay = 0.03):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(delay)
    print()
Round = 1
item = Items.Items()


def main_menu():
    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load("Game\Music_Blood_Hunt\mixkit-tapis-615.mp3") 
    pygame.mixer.music.play(-1)

    global Menu_active
    while Menu_active == 1:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("====================================================================")
        print("                         BLOOD HUNT")
        print("                  GARDENS OF ROSES AND SORROWS")
        print("====================================================================")
        print("1. Starten")
        print("2. Anleitung")
        print("3. Beenden")
        print("====================================================================")

        wahl = input("Wähle eine Option aus von (1-3): ")
        if wahl == ("1"):
            Menu_active = 0
            starte_spiel()
        elif wahl == ("2"):
            anleitung()
        elif wahl == ("3"):
            langsamer_text("Spiel wird beendet!!")
            pygame.quit()
            sys.exit()
        else:
            print("ungültige Angabe")

def anleitung():
    os.system('cls' if os.name == 'nt' else 'clear')
    print("\n=== Anleitung ===\n")
    print("-Kämpfe gegen Gegner.")
    print("-Sammle Items")
    print("-Besiege die Rosenkönigin")
    print()
    input("Drücke ENTER-Taste für zurück. \n")


def starte_spiel():
    os.system('cls' if os.name == 'nt' else 'clear')
    pygame.mixer.music.stop()
    langsamer_text("Aria... einst eine friedliche Stadt voller Musik und Blumen.")
    langsamer_text("Doch diese Zeiten sind vorbei.")
    langsamer_text("Ein süßer, unheilvoller Rosenduft liegt über den Straßen.")
    langsamer_text("Menschen verschwinden und wer zurückkehrt, ist von Dornen umhüllt.")
    langsamer_text("Die Finstere Rosenkönigin Rosamira hat ihr Dornenschloss über das Land ausgebreitet.")
    langsamer_text("Lebende Ranken wuchern durch die Stadt, verwandeln Menschen in Kreaturen.")
    langsamer_text("\nDu bist der letzte Überlebende")
    langsamer_text("\nDeine Mission:")
    langsamer_text(" - Die Stadt Aria retten")
    langsamer_text(" - Die Dornen vernichten")
    langsamer_text(" - Die Rosenkönigin töten\n")
    input("Drücke ENTER um fortzufahren...\n")
    pygame.mixer.music.stop()

def pre_tutorial_fight():
    pygame.mixer.music.load("Game\Music_Blood_Hunt\ghost-moon-lullaby-304719.mp3")
    pygame.mixer.music.play(-1)
    langsamer_text(f"Du wachst am Rand einer gepflasterten Straße auf und dein Kopf dröhnt, du kannst dich an nichts erinnern... \nBeim aufrichten fällt dir auf, dass du die Kleidung eines {klasse_name} trägst. Der Anblick verwundert dich, aber das Gefühl der Kleidung auf deiner Haut, \nder Druck deiner Waffen an deiner Hüffte und die etwas zu großen Schuhe fühlt sich mehr als bekannt an. \nAls hättest du nie etwas anderes getragen.\nDie Stadt wirkt verlassen, aber in der Ferne erkennst du ein Schloss, \ndas im Vergleich fast schon Lebendig wirkt. Im Inneren brennt ein Feuer. Plötzlich sticht ein süßer, unheilvoller Rosenduft deine Nase und du schätzt, \ndass er aus dem Schloss kommt. Du beschließt, dem Duft zu folgen, in der Hoffnung, Antworten auf deine Fragen zu finden...\n")
    langsamer_text(f"Als du dich dem Schloss näherst, bemerkst du eine Gestalt im Schatten der Mauer stehen.")
    input("Drücke ENTER um fortzufahren...\n")
    pygame.mixer.music.stop()

shield = 0

def fight_logic():
    
    global cha
    global wep
    global item
    global Round
    global klasse_name
    global shield
    enemies_instance = EnemiesPage.enemies()
    methods = [name for name, method in inspect.getmembers(EnemiesPage.enemies, predicate=inspect.isfunction) 
               if not name.startswith('_')]
    random_enemy = random.choice(methods)
    # Call the random enemy method (this will print which enemy appears)
    getattr(enemies_instance, random_enemy)()
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"Round {Round} out of 5.")
    print("=================================================")
    print(f"A wild {random_enemy.replace('enemy_', '').capitalize()} appears!")
    print("=================================================")
    
    while cha.hitpoints > 0 and enemies_instance.hitpoints > 0:
        action = input(f"\n|You have {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP |\n \n/\ The Enemy ({enemies_instance.strength - cha.armor} DMG next Turn) {random_enemy.replace('enemy_', '').capitalize()} has {enemies_instance.hitpoints} HP /\ \n \nChoose your Action: \n| 1. Attack | 2. Shield (for {cha.armor}) | 3. Potion/Items | 4. Exit |").strip().lower()

    #=====================================================================================ATTACK LOGIC=======================================================================================#
        if action == "1" or action == "attack":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"\n|You have {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP | {klasse_name.capitalize()}\n \n/\ The Enemy {random_enemy.replace('enemy_', '').capitalize()} has {enemies_instance.hitpoints} HP /\ ")
            print(f"\nThe Enemy will attack you for {enemies_instance.strength - cha.armor} damage! \nWhat attack will you do?")
            attack_type = input(f"Choose an Attack!: \n \n| 1 Attack = {wep.attack_classic} DMG | 2 Special Attack = {wep.attack_special} DMG {wep.attack_special_manacost} MP | 3 Ultimate Attack = {wep.attack_ultimate} DMG {wep.attack_ultimate_manacost} MP | ").strip().lower()
            if attack_type == "1" or attack_type == "attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_classic * 2
                    chect = 1
                    cha.magicpoints += 10
                else:
                    damage = wep.attack_classic
                    chect = 0
                    cha.magicpoints += 10
            elif attack_type == "2" or attack_type == "special attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_special * 2
                    chect = 1
                    
                else:
                    damage = wep.attack_special
                    chect = 0
                cha.magicpoints -= wep.attack_special_manacost
            elif attack_type == "3" or attack_type == "ultimate attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_ultimate * 2
                    chect = 1
                else:
                    damage = wep.attack_ultimate
                    chect = 0
                cha.magicpoints -= wep.attack_ultimate_manacost
            if random.randint(1,100) <= enemies_instance.dodgechance * 10:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"===============\n|ENEMY DODGED!|\n===============\nThe {random_enemy.replace('enemy_', '').capitalize()} has dodged your attack!You dealt no damage. Enemy HP is still at {enemies_instance.hitpoints}.")
            else:
                if chect == 0:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    enemies_instance.hitpoints -= damage
                    print(f"You dealt {damage} damage to the enemy. Enemy HP is now at {enemies_instance.hitpoints}.")
                else:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    enemies_instance.hitpoints -= damage
                    print(f"===============\n|CRITICAL HIT!|\n===============\nYou're crit dealt {damage} damage to the enemy. Enemy HP is now at {enemies_instance.hitpoints}.")
                    time.sleep(1)
            if enemies_instance.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"You have defeated the {random_enemy.replace('enemy_', '').capitalize()}!")
                cha.hitpoints += 15
                cha.magicpoints += 10
                if cha.hitpoints > cha.maxhp:
                    cha.hitpoints = cha.maxhp
                if cha.magicpoints > cha.maxmp:
                    cha.magicpoints = cha.maxmp
                print(f"You recovered 15 HP and 10 MP. Your current HP is {cha.hitpoints} and MP is {cha.magicpoints}.")
                time.sleep(3)
                if Round < 10:
                    print("Prepare for the next round!")
                    time.sleep(2)
            elif cha.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print("You have been defeated...")
                                    
    #=====================================================================================DEFEND LOGIC=======================================================================================#
        elif action == "2" or action == "defend":
            print("You defend against the enemy's attack!")
            shield = cha.armor
            cha.magicpoints += 10
            os.system('cls' if os.name == 'nt' else 'clear')
    #=====================================================================================ITEM LOGIC=======================================================================================#
        elif action == "3" or action == "potion":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"You use a potion to heal yourself for {item.health_potion_healing}!")
            cha.hitpoints = cha.hitpoints + item.health_potion_healing
            if cha.hitpoints > cha.maxhp:
                cha.hitpoints = cha.maxhp
                cha.magicpoints += 10
            print(f"Your HP is now {cha.hitpoints}.")
        elif action == "exit":
            print("Exiting the fight.")
            Round = 11
            return Round
            
            
        else:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("Invalid action. Please choose again.")
        if enemies_instance.hitpoints > 0:
            if random.randint(1,100) <= cha.dodgechance:
                print(f"===============\n|YOU DODGED!|\n===============\nYou have dodged the {random_enemy.replace('enemy_', '').capitalize()}'s attack!")
            elif enemies_instance.hitpoints > 0:
                if random.randint(1,100) <= enemies_instance.critchance * 10:
                    enemy_damage = enemies_instance.strength * 2 - cha.armor
                    cha.hitpoints -= enemy_damage
                    print(f"===============\n|THE {random_enemy.replace('enemy_', '').capitalize()} HAS CRIT \n===============\n He hit you for {enemy_damage} damage!|\n===============")
                else:
                    enemy_damage = enemies_instance.strength - cha.armor - shield
                    cha.hitpoints -= enemy_damage 
                    shield = 0
                    print(f"The {random_enemy.replace('enemy_', '').capitalize()} attacks you and deals {enemy_damage} damage!")
            
        
def fight_loop():
    pygame.mixer.music.load("Game\Music_Blood_Hunt\Aufzeichnung 2025-12-04 162218.mp3")
    pygame.mixer.music.play(-1)
    global Round
    Round = 1
    while Round < 6:
        fight_logic()
        Round += 1
    pygame.mixer.music.stop()

def post_tutorial_fight():
    pygame.mixer.music.load("Game\Music_Blood_Hunt\ghost-moon-lullaby-304719.mp3")
    pygame.mixer.music.play(-1)
    os.system('cls' if os.name == 'nt' else 'clear')
    print("="*90)
    print("\nDu hast das Tutorial abgeschlossen!\nIm Schloss erwarten dich Horden von Gegenern die dich aufhalten wollen und der ein oder andere Boss.\nViel Spaß!\n")
    print("="*90)
    input("Drücke ENTER um fortzufahren...\n")
    os.system('cls' if os.name == 'nt' else 'clear')
    langsamer_text("Der Orc fällt zu Boden. Getötet. Durch deine Hand.\n\nDer Geruch der Rosen wurde plötzlich intensiver, als wäre das Schloss selbst von deiner Tat erzürnt.\nObwohl du nicht weißt wer du bist, trotz der beunruhigenden Fähigkeiten deines eigenen Körpers ist dir eins klar...\nDie Quelle des Rosenduftes muss zerstört werden!\n")
    input("Drücke ENTER um fortzufahren...\n")
    os.system('cls' if os.name == 'nt' else 'clear')
    langsamer_text("Du schreitest voran, durch das offenstehene Tor in das Innere des Schlosses hinein...\n")
    langsamer_text("Das innere des Schlosses ist das genaue Gegenteil der verlassenen Stadt draußen. \nNicht nur die prunkvoll dekorierten Wände und Böden, sondern auch die Stille ist hier nicht vorhanden.")
    langsamer_text("Von überall her hörst du Anzeichen von Leben. Aber irgendetwas fühlt sich falsch an...\n")
    langsamer_text("Als du um die Ecke biegst, kommst du in einen großen Raume, dekoriert mit sämtlichen Schätzen und jeweils 6 Pfeiler links und rechts, \nwelche den Raum uneinsichtlich machen. In der Mitte befindet sich ein kleines Armeecamp. \n'Im Inneren des Schlosses?'Fragst du dich.\n")
    langsamer_text("Du näherst dich vorsichtig dem Camp, als plötzlich es in deinem Kopf click macht. Deshalb haben die Geräusche sich etwas falsch angehört, \nsie kamen nicht von Menschen, sondern von Monstern!")
    langsamer_text("\nIm Rand deines Sichtfeldes bemerkst du etwas und es hat dich auch gesehen! \nDu begibst dich an die Wand des Raumes, um ja nicht umzingelt zu werden, und bereitest dich auf den Kampf vor!\n")
    input("Drücke ENTER um fortzufahren...\n")
    pygame.mixer.music.stop()

def Tutorial_fight():
    global cha
    global wep
    global item
    global Round
    global klasse_name
    global shield
    global tut

    enemies_instance = EnemiesPage.tutorial_enemy()
    enemies_instance.training()
    os.system('cls' if os.name == 'nt' else 'clear')
    tut = 0
    attack_allowed = 0
    while cha.hitpoints > 0 and enemies_instance.hitpoints > 0:
        if tut == 0:
            print("=" * 20 + "\nTutorial\n" + "=" * 20 + "\nDu befindest dich im Kampf gegen einen Orc! \n")
            print(f"\nDu kannst jetzt mit 1 Angreifen, 2 Verteidigen oder 3 einen Heiltrank benutzen. (mit 4 das spiel beenden)\n")
            print(f"Drücke 1 um jetzt eine Attacke auszuwählen!")
        elif tut == 1:
            print("=" * 20 + "\nTutorial\n" + "=" * 20 + "\nDu willst dich jetzt verteidigen! \n")
            print(f"\nDer Orc wird jetzt weniger Schaden bei seinem nächsten Angriff machen. \n")
            print(f"Drücke 2 um dich zu Verteidigen!")
        elif tut == 2:
            print("=" * 20 + "\nTutorial\n" + "=" * 20 + "\nDu willst dich nun heilen! \n")
            print(f"\nDu wirst etwas Leben zurückbekommen. \n")
            print(f"Drücke 3 um einen Heiltrank zu benutzen!")
        action = input(f"\n|Du hast {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP |\n \n| Der Orc ({enemies_instance.strength - cha.armor} DMG nächster Zug) hat {enemies_instance.hitpoints} HP | \n \nWähle deine Aktion: \n| 1. Angriff | 2. Verteidigen (für {cha.armor}) | 3. Trank/Items | 4. Beenden |").strip().lower()
    #=====================================================================================ATTACK LOGIC=======================================================================================#
        if tut == 0 and (action == "1" or action == "attack"):
            tut = tut + 1
            attack_allowed = 1
            os.system('cls' if os.name == 'nt' else 'clear')
            print("="*60)
            print("Du hast dich entschieden anzugreifen! \nWähle jetzt eine deiner Attacken aus um den Orc zu besiegen!")
            print("="*60)
            print(f"\n|Du hast {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP | {klasse_name.capitalize()}\n \n| Der Orc hat {enemies_instance.hitpoints} HP |  ")
            print(f"\nDer Orc wird dich für {enemies_instance.strength - cha.armor} Schaden angreifen! \nWelche Attacke möchtest du ausführen?")
            attack_type = input(f"Wähle eine Attacke!: \n \n| 1 Angriff = {wep.attack_classic} DMG | 2 Spezialangriff = {wep.attack_special} DMG {wep.attack_special_manacost} MP | 3 Ultimativer Angriff = {wep.attack_ultimate} DMG {wep.attack_ultimate_manacost} MP | ").strip().lower()
            if attack_type == "1" or attack_type == "angriff":
                if random.randint(1,100) <= cha.dexterity * 0:
                    print("Kritischer Treffer!")
                    damage = wep.attack_classic * 2
                    chect = 1
                    time.sleep(1)
                else:
                    damage = wep.attack_classic
                    chect = 0
            elif attack_type == "2" or attack_type == "spezialangriff":
                if random.randint(1,100) <= cha.dexterity * 0:
                    print("Kritischer Treffer!")
                    damage = wep.attack_special * 2
                    chect = 1
                    time.sleep(1)
                else:
                    damage = wep.attack_special
                    chect = 0
                cha.magicpoints -= wep.attack_special_manacost
            elif attack_type == "3" or attack_type == "ultimativer angriff":
                if random.randint(1,100) <= cha.dexterity * 0:
                    print("Kritischer Treffer!")
                    damage = wep.attack_ultimate * 2
                    chect = 1
                    time.sleep(1)
                else:
                    damage = wep.attack_ultimate
                    chect = 0
                cha.magicpoints -= wep.attack_ultimate_manacost
            if random.randint(1,100) <= enemies_instance.dodgechance * 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"===============\n|DER GEGNER IST AUSGEWICHEN!|\n===============\nDer Orc hat deinen Angriff ausgewichen! Du hast keinen Schaden verursacht. Die HP des Gegners sind immer noch bei {enemies_instance.hitpoints}.")
            else:
                if chect == 0:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    enemies_instance.hitpoints -= damage
                    print("="*60)
                    print(f"Du hast {damage} Schaden beim Gegner verursacht. Die HP des Gegners sind jetzt bei {enemies_instance.hitpoints}.")
                else:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    enemies_instance.hitpoints -= damage
                    print(f"===============\n|KRITISCHER TREFFER!|\n===============\nDu hast {damage} Schaden beim Gegner verursacht. Die HP des Gegners sind jetzt bei {enemies_instance.hitpoints}.")
            if enemies_instance.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"Du hast den Orc besiegt! Nun beginnt dein Abenteuer richtig...")
                time.sleep(3)
            elif cha.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print("You have been defeated...")
                                    
    #=====================================================================================DEFEND LOGIC=======================================================================================#
        elif tut == 1 and (action == "2" or action == "verteidigen"):
            os.system('cls' if os.name == 'nt' else 'clear')
            print("="*80)
            print("Du verteidigst dich gegen den Angriff des Gegners!")
            shield = cha.armor
            tut = tut + 1
    #=====================================================================================ITEM LOGIC=======================================================================================#
        elif tut == 2 and (action == "3" or action == "potion") :
            tut = 0
            os.system('cls' if os.name == 'nt' else 'clear')
            print("="*80)
            print(f"Du hast einen Heiltrank benutzt um {item.health_potion_healing} HP wiederherzustellen!")
            cha.hitpoints = cha.hitpoints + item.health_potion_healing
            if cha.hitpoints > cha.maxhp:
                cha.hitpoints = cha.maxhp
            print(f"Deine HP ist jetzt {cha.hitpoints}.")
        elif action == "exit":
            print("Exiting the fight.")
            Round = 11
            return Round
        else:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("="*20 + "\nBefolge bitte dem Tutorial!\n" + "="*20)
            time.sleep(2)
        if attack_allowed == 1 and enemies_instance.hitpoints > 0 :
            if random.randint(1,100) <= cha.dodgechance * 0:
                print(f"===============\n|YOU DODGED!|\n===============\nYou have dodged the Orc's attack!")
            elif enemies_instance.hitpoints > 0:
                if random.randint(1,100) <= enemies_instance.critchance * 10:
                    enemy_damage = enemies_instance.strength * 2 - cha.armor
                    cha.hitpoints -= enemy_damage
                    print(f"="*20 + "\n|KRITISCHER TREFFER VON ORC|\n""="*20 + f"\n Er hat dich für {enemy_damage} Schaden getroffen!|\n===============")
                else:
                    enemy_damage = enemies_instance.strength - cha.armor - shield
                    cha.hitpoints -= enemy_damage 
                    shield = 0
                    print(f"Der Orc greift dich an und verursacht {enemy_damage} Schaden!")
                    print("="*60)
                    time.sleep(2)
                    input("Drücke ENTER um fortzufahren...\n")
                    os.system('cls' if os.name == 'nt' else 'clear')
def pre_boss_fight():
    pygame.mixer.music.load("Game\Music_Blood_Hunt\Aufzeichnung 2025-12-04 162218.mp3")
    pygame.mixer.music.play(-1)
    os.system('cls' if os.name == 'nt' else 'clear')
    langsamer_text("10 Monster liegen besiegt hinter dir. Doch das Schloss ist mit dir noch nicht zuende.\n")
    langsamer_text("In der mitte des Camps steht ein 3 Meter großes Skellett, umgeben von Dornenranken und einer silbernen Rüstung.\n")
    langsamer_text("„DU KOMMST HIER NICHT VORBEI!! BRUTUS MUSS MEINE KÖNIGIN BESCHÜTZEN!  MUSS DEN EINDRINGLING BESEITIGEN!!!“")
    input("Drücke ENTER um fortzufahren...\n")
    pygame.mixer.music.stop()

def post_boss_fight():
    pygame.mixer.music.load("Game\Music_Blood_Hunt\Aufzeichnung 2025-12-04 162218.mp3")
    pygame.mixer.music.play(-1)
    os.system('cls' if os.name == 'nt' else 'clear')
    langsamer_text("„meine Königin... vergibt mir...“ flüstert Brutus, bevor er zu Boden sinkt.\n")
    langsamer_text("Die Dornenranken um ihn herum beginnen zu welken und zu sterben.\nDu schreitest nun die Treppe hinauf, tiefer in das Schloss hinein.\n")
    langsamer_text("Eine Weller der Stärke durchströmt deinen Körper. Du fühlst dich stärker, als je zuvor.\n")
    cha.maxhp += 50
    cha.hitpoints = cha.maxhp
    langsamer_text(f"Deine maximale Gesundheit ist nun {cha.maxhp}!\n")
    time.sleep(4)
    os.system('cls' if os.name == 'nt' else 'clear')
    print("="*20 + "\nSTAGE 1 COMPLETE!\n" + "="*20)
    pygame.mixer.music.stop()


def boss_fight():
    pygame.mixer.music.load("Game\Music_Blood_Hunt\operational-focus-fast-thrash-metal-instrumental-391329.mp3")
    pygame.mixer.music.play(-1)
    global cha
    global wep
    global item
    global Round
    global klasse_name
    global shield
    boss = EnemiesPage.boss_enemies()
    boss.boss_Brutus()
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"Boss Fight!")
    print("=================================================")
    print(f"Brutus appears!")
    print("=================================================")
    while cha.hitpoints > 0 and boss.hitpoints > 0:
        action = input(f"\n|You have {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP |\n \n/\ The Enemy ({boss.strength - cha.armor} DMG next Turn) Brutus has {boss.hitpoints} HP /\ \n \nChoose your Action: \n| 1. Attack | 2. Shield (for {cha.armor}) | 3. Potion/Items | 4. Exit |").strip().lower()
    #=====================================================================================ATTACK LOGIC=======================================================================================#
        if action == "1" or action == "attack":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"\n|You have {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP | {klasse_name.capitalize()}\n \n/\ The Enemy Brutus has {boss.hitpoints} HP /\ ")
            print(f"\nThe Enemy will attack you for {boss.strength - cha.armor} damage! \nWhat attack will you do?")
            attack_type = input(f"Choose an Attack!: \n \n| 1 Attack = {wep.attack_classic} DMG | 2 Special Attack = {wep.attack_special} DMG {wep.attack_special_manacost} MP | 3 Ultimate Attack = {wep.attack_ultimate} DMG {wep.attack_ultimate_manacost} MP | ").strip().lower()
            if attack_type == "1" or attack_type == "attack":
                if random.randint(1,100) <= cha.dexterity:
                    print("Critical Hit!")
                    damage = wep.attack_classic * 2
                    chect = 1
                    cha.magicpoints += 5
                else:
                    damage = wep.attack_classic
                    chect = 0
                    cha.magicpoints += 5
            elif attack_type == "2" or attack_type == "special attack":
                if random.randint(1,100) <= cha.dexterity:
                    print("Critical Hit!")
                    damage = wep.attack_special * 2
                    chect = 1
                    
                else:
                    damage = wep.attack_special
                    chect = 0
                cha.magicpoints -= wep.attack_special_manacost
            elif attack_type == "3" or attack_type == "ultimate attack":
                if random.randint(1,100) <= cha.dexterity:
                    print("Critical Hit!")
                    damage = wep.attack_ultimate * 2
                    chect = 1
                else:
                    damage = wep.attack_ultimate
                    chect = 0
                cha.magicpoints -= wep.attack_ultimate_manacost
            if random.randint(1,100) <= boss.dodgechance * 10:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"===============\n|ENEMY DODGED!|\n===============\nBrutus has dodged your attack!You dealt no damage. Enemy HP is still at {boss.hitpoints}.")
            else:
                if chect == 0:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    boss.hitpoints -= damage
                    print(f"You dealt {damage} damage to the enemy. Enemy HP is now at {boss.hitpoints}.")
                else:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    boss.hitpoints -= damage
                    print(f"===============\n|CRITICAL HIT!|\n===============\nYou're crit dealt {damage} damage to the enemy. Enemy HP is now at {boss.hitpoints}.")
            if boss.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"You have defeated Brutus!")
                cha.hitpoints = cha.maxhp
                cha.magicpoints = cha.maxmp
                time.sleep(2)
                pygame.mixer.music.stop()
            elif cha.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print("You have been defeated...")
                pygame.mixer.music.stop()
                                    
    #=====================================================================================DEFEND LOGIC=======================================================================================#
        elif action == "2" or action == "defend":
            print("You defend against the enemy's attack!")
            shield = cha.armor
            cha.magicpoints += 5
            os.system('cls' if os.name == 'nt' else 'clear')
    #=====================================================================================ITEM LOGIC=======================================================================================#
        elif action == "3" or action == "potion":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"You use a potion to heal yourself for {item.health_potion_healing}!")
            cha.hitpoints = cha.hitpoints + item.health_potion_healing
            if cha.hitpoints > cha.maxhp:
                cha.hitpoints = cha.maxhp
                cha.magicpoints += 5
            print(f"Your HP is now {cha.hitpoints}.")
        elif action == "exit":
            print("Exiting the fight.")
            Round = 11
            return Round
            
            
        else:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("Invalid action. Please choose again.")
        if boss.hitpoints > 0:
            if random.randint(1,100) <= cha.dodgechance:
                print(f"===============\n|YOU DODGED!|\n===============\nYou have dodged Brutus's attack!")
            elif boss.hitpoints > 0:
                if random.randint(1,100) <= boss.critchance * 10:
                    enemy_damage = boss.strength * 2 - cha.armor
                    cha.hitpoints -= enemy_damage
                    print(f"===============\n|BRUTUS HAS CRIT \n===============\n He hit you for {enemy_damage} damage!|\n===============")
                else:
                    enemy_damage = boss.strength - cha.armor - shield
                    cha.hitpoints -= enemy_damage 
                    shield = 0
                    print(f"Brutus attacks you and deals {enemy_damage} damage!")
#=================================START GAME============================================================================================================================================#

Menu_active = 1

main_menu()

Menu_active = 0
pygame.mixer.music.load("Game\Music_Blood_Hunt\intense-rain-city-night-171461.mp3")
pygame.mixer.music.play(-1)
#==========================MYSTISCHE KLASSENAUSWAHL WARUM FUNKTIONIERT NICHTS IN EINER DEF AAAAAAAAAAAAAAAAAA=========================================================================================================================# ich kann nimmer
cha = Classes.klassen()
kc = 1
klasse_name = ""
while kc == 1:
    os.system('cls' if os.name == 'nt' else 'clear')
    langsamer_text("Du bist da... Du siehst nichts...")
    langsamer_text("Das Einzige was du hörst, ist der Klang des Regens.. ")
    langsamer_text("Du weißt nicht mehr wer du bist..")
    langsamer_text("Doch du kannst dich erinnern was du bist..\n")
    klasse = str(input("Also was bist du?? gib ein (Krieger, Magier , Assassine): ")).lower()
    if klasse == "krieger":
        cha.klasse_krieger()
        print("Sie spielen einen Krieger!")
        kc = 2
        klasse_name = "krieger"
    elif klasse == "magier":
        cha.klasse_magier()
        print("Sie spielen einen Magier!")
        kc = 2
        klasse_name = "magier"
    elif klasse == "assassine":
        cha.klasse_assassine()
        print("Sie spielen einen Assasine!")
        kc = 2
        klasse_name = "assasine"
            # Erst die Klasse setzena
            # Dann die Waffe mit den korrekten Stats
    else:
        print("Invalid action. Please choose again.")
    os.system('cls' if os.name == 'nt' else 'clear')

        # MUSS NACH DER KLASSENINITIALISIERUNG KOMMEN
class Weapons:
    def __init__(self):
        self.attack_classic = 10
        self.attack_special = 15
        self.attack_ultimate = 25
            
    def sword(self):
        self.attack_classic = 12 + cha.strength
        self.attack_special = 18 + cha.strength
        self.attack_special_manacost = 5
        self.attack_ultimate = 30 + cha.strength
        self.attack_ultimate_manacost = 15

    def dagger(self):
        self.attack_classic = 10 + cha.dexterity
        self.attack_special = 20 + cha.dexterity
        self.attack_special_manacost = 5
        self.attack_ultimate = 28 + cha.dexterity
        self.attack_ultimate_manacost = 15
        
    def staff(self):
        self.attack_classic = 8 + cha.intelligence
        self.attack_special = 22 + cha.intelligence
        self.attack_special_manacost = 5
        self.attack_ultimate = 32 + cha.intelligence
        self.attack_ultimate_manacost = 15

wep = Weapons()
if klasse == "krieger":
    wep.sword()
elif klasse == "magier":
    wep.staff()
elif klasse == "assassine":
    wep.dagger()

#===============================KAMPF============================================================================================================================================#
pygame.mixer.music.stop()
Tutorial_fight()
post_tutorial_fight()
fight_loop()
pre_boss_fight()
boss_fight()
post_boss_fight()