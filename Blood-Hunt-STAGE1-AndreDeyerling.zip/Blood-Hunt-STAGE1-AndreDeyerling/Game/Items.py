class Items:
    health_potion_healing = 50
   
    
        